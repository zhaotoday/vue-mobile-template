import { createApi } from "vue-mobile/@lr/utils/create-api";

export const publicAppUpgradesApi = createApi({
  url: "/public/appUpgrades",
});
