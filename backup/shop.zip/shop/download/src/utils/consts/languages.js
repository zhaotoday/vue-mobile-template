export const Languages = [
  {
    label: "English",
    value: "en",
  },
  {
    label: "中文",
    value: "zh-Hans",
  },
];
