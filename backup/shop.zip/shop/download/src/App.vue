<script>
export default {
  onLaunch() {},
  onHide() {},
};
</script>

<style lang="scss">
@import "~uview-ui/index.scss";
@import "./assets/styles/global/index.scss";
</style>
