export const zhHans = {};
