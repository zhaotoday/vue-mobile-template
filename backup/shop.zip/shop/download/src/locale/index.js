import { en } from "./en";
import { zhHans } from "./zh-Hans";

export const locale = { en, "zh-Hans": zhHans };
