export const OrderStatus = [
  {
    label: "全部",
    value: "",
  },
  {
    label: "待配送",
    value: "ToDistribute",
  },
  {
    label: "配送中",
    value: "Distributing",
  },
  {
    label: "已完成",
    value: "Finished",
  },
];
