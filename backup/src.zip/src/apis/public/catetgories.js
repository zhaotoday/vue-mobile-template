import { createApi } from "vue-mobile/@lr/utils/create-api";

export const publicCategoriesApi = createApi({
  url: "/public/categories",
});
