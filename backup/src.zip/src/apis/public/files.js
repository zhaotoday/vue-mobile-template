import { createApi } from "vue-mobile/@lr/utils/create-api";

export const publicFilesApi = createApi({
  url: "/public/files",
});
