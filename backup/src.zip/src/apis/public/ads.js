import { createApi } from "vue-mobile/@lr/utils/create-api";

export const publicAdsApi = createApi({
  url: "/public/ads",
});
