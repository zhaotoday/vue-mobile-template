import { createApi } from "vue-mobile/@lr/utils/create-api";

export const publicProductsApi = createApi({
  url: "/public/products",
});
