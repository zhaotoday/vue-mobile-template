import Vue from "vue";
import VueCompositionAPI from "@vue/composition-api";
import UniCompositionAPI from "uni-composition-api";

Vue.use(VueCompositionAPI);
Vue.use(UniCompositionAPI);
