<template>
  <div class="c-example">example</div>
</template>

<script src="./script.js"></script>

<style lang="scss" src="./style.scss"></style>
