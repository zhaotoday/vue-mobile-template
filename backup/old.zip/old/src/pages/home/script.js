import avatarUrl from "vue-mobile/assets/images/components/avatar/default.png";

export default {
  setup() {
    return { avatarUrl };
  },
};
